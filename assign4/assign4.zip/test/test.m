function [x_fixed_scaled, binary_repr] = fixed_point(x, int_bits, frac_bits)
    scale_factor = 2 ^ frac_bits; % Scale up
    total_bits = int_bits + frac_bits; % Total bits (sign included in int_bits)
    max_val = 2^(total_bits - 1) - 1; % Max range
    min_val = -2^(total_bits - 1); % Min range

    % Convert to fixed-point integer representation
    x_fixed = round(x * scale_factor); % Scale & round
    x_fixed = max(min(x_fixed, max_val), min_val); % Clip to avoid overflow

    % Convert to Two’s Complement binary representation
    binary_repr = arrayfun(@(num) dec2bin(mod(num, 2^total_bits), total_bits), x_fixed, 'UniformOutput', false);

    % Convert back to fixed-point scaled value
    x_fixed_scaled = x_fixed/scale_factor;
end


function num = fixed_point_to_num(bin_string, int_bits, frac_bits)
    total_bits = int_bits + frac_bits; % Total number of bits
    is_negative = (bin_string(1) == '1'); % Check if negative (MSB is 1)

    % Convert binary string to integer
    int_value = bin2dec(bin_string);

    % Handle two’s complement for negative numbers
    if is_negative
        int_value = int_value - 2^total_bits;
    end

    % Scale down to get the actual value
    num = int_value / (2^frac_bits);
end




[x_scaled, x_binary] = fixed_point(ones(1,500), 2, 14);
[h_scaled, h_binary] = fixed_point(ones(1,20), 2, 14);
conv_result_m = conv(x_scaled, h_scaled, "full");

writecell(transpose(h_binary), 'filter_coeff_bin.txt');
writecell(transpose(x_binary), 'input.txt');

fileID = fopen('conv_res.txt', 'r'); 
data = textscan(fileID, '%s');  % Read as cell array of strings
fclose(fileID);

conv_fpga_res = fixed_point_to_num(cell2mat(data{1}), 7, 13);
mean_error = sum(abs(transpose(conv_fpga_res) - conv_result_m))

plot(conv_result_m)
hold on;
plot(conv_fpga_res)
hold off;